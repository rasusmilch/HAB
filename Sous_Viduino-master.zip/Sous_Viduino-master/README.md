Sous-Viduino
============
Sous-vide powered by Arduino - The SousViduino!

This is the code from Bill Earl for the Adafruit Sous-vide tutorial using an Arduino. Check it out at http://learn.adafruit.com/sous-vide-powered-by-arduino-the-sous-viduino