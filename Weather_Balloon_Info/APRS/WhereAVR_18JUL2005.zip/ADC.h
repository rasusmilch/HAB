/*******************************************************************************
File:			ADC.h

				Analog to Digital module definitions/declarations.

Version:		1.00

*******************************************************************************/

// external function prototypes
extern void					ADCInit(void);
extern unsigned short	ADCGet(unsigned char chan);
