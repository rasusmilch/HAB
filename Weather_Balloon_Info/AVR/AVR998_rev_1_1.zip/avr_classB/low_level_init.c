//!
//! @file $RCSfile: low_level_init.c,v $
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief Main module : It is based on an infinite loop
//! @brief This module provides to IEC 60730 Class B start up test.\n
//!      It is called during IAR C Compiler startup sequence \n
//! SP and Y(R28/R29) must be saved before test because they are already init.\n
//!
//! @version $Revision: 1.3 $
//!


#include <classB_config.h>

#ifdef __cplusplus
extern "C" {
#endif

char __low_level_init()
{
  /* RO to R31 stuck test
     Move data between register
     R31, R30, R29, R28 and R27 are tested before
     to be reuse after during the test  */
  
      //   R31 stuck test
__asm("R31_0x55_TST:                              \n"
      "               ldi  R31, $55               \n"
      "               cpi  R31, $55               \n"
      "               breq  R31_0xAA_TST          \n"  
      "               jmp  Failure                \n"
      "R31_0xAA_TST:  ldi  R31, $AA               \n"
      "               cpi  R31, $AA               \n"
      "               breq  R30_0x55_TST          \n"  
      "               jmp  Failure                \n"
);

      //   R30 stuck test
__asm("R30_0x55_TST:  ldi  R30, $55               \n"
      "               cpi  R30, $55               \n"
      "               breq  R30_0xAA_TST          \n"  
      "               jmp  Failure                \n"
      "R30_0xAA_TST:  ldi  R30, $AA               \n"
      "               cpi  R30, $AA               \n"
      "               breq  R28_0x55_TST          \n"
      "               jmp  Failure                \n"
);

      //   R29 stuck test
__asm("R29_0x55_TST:  mov R31, R29     ; save R29 \n"    
      "                ldi  R29, $55              \n"    
      "               cpi  R29, $55               \n"
      "               breq  R29_0xAA_TST          \n"
      "               jmp  Failure                \n"
      "R29_0xAA_TST:  ldi  R29, $AA               \n"
      "               cpi  R29, $AA               \n"
      "               breq  R29_END_TST           \n"  
      "               jmp  Failure                \n"
      "R29_END_TST:   mov R29, R31  ; restore R29 \n" 
);

      //   R28 stuck test
__asm("R28_0x55_TST:  mov R31, R28     ; save R28 \n"
      "               ldi  R28, $55               \n"
      "               cpi  R28, $55               \n"
      "               breq  R28_0xAA_TST          \n"  
      "               jmp  Failure                \n"
      "R28_0xAA_TST:  ldi  R28, $AA               \n"
      "               cpi  R28, $AA               \n"
      "               breq  R28_END_TST           \n"  
      "               jmp  Failure                \n"
      "R28_END_TST:   mov R28, R31  ; restore R28 \n"    
);


      //   R27 stuck test
__asm("R27_0x55_TST:                              \n"
      "               ldi  R27, $55               \n"
      "               cpi  R27, $55               \n"
      "               breq  R27_0xAA_TST          \n"  
      "               jmp  Failure                \n"
      "R27_0xAA_TST:  ldi  R27, $AA               \n"
      "               cpi  R27, $AA               \n"
      "               breq  R27_END_TST           \n"  
      "               jmp  Failure                \n"
      "R27_END_TST:                               \n"    
);


      // R0 to R27 stuck test
__asm("RX_TST:        ldi  R30,$00                \n"
      "               ldi  R31,$00                \n"
      "RX_0x55_TST:   ldi  R27,$55                \n"
      "               st  Z,R27                   \n"
      "               ldi  R27,$00                \n"
      "               ld  R27,Z                   \n"
      "               cpi  R27,$55                \n"
      "               breq  RX_0xAA_TST           \n"
      "               jmp  Failure                \n"
      "RX_0xAA_TST:   ldi  R27,$AA                \n"
      "               ST  Z,R27                   \n"
      "               ldi  R27,$00                \n"
      "               ld  R27,Z+                  \n"
      "               cpi  R27, $AA               \n"
      "               breq  RX_TST_2              \n"
      "               jmp  Failure                \n"
      "RX_TST_2:      cpi  r30,27 ; test until R27 \n"
      "               brne  RX_0x55_TST           \n"
);

  // Stack pointer Stuck Test (16 bit Stack pointer)
  // Save SP values
__asm("SP_TST:        in    R23,$3E               \n"
      "               in    R22,$3D               \n"
      "SPL_0x55_TST:  ldi   R24,$55               \n"
      "               out   $3D,R24               \n"
      "               in    R24,$3D               \n"
      "               cpi   R24,$55               \n"
      "               breq  SPL_0xAA_TST          \n"
      "               jmp   Failure               \n"
      "SPL_0xAA_TST:  ldi   R24,$AA               \n"
      "               out   $3D,R24               \n"
      "               in    R24,$3D               \n"
      "               cpi   R24,$AA               \n"
      "               breq  SPH_0x55_TST          \n"
      "               jmp   Failure               \n"
      "SPH_0x55_TST:  ldi   R25,"SPH_MASK
      "               andi  R25,$55               \n"
      "               out   $3E,R25               \n"
      "               in    R24,$3E               \n"
      "               cp    R24,R25               \n"
      "               breq  SPH_0xAA_TST          \n"
      "               jmp   Failure               \n"
      "SPH_0xAA_TST:  ldi   R25,"SPH_MASK
      "               andi  R25,$AA               \n"
      "               out   $3E,R25               \n"
      "               in    R24,$3E               \n"
      "               cp    R24,R25               \n"
      "               breq  RESTORE_SP            \n"
      "               jmp   Failure               \n"
      "RESTORE_SP:    out   $3E,R23               \n"
      "               out   $3D,R22               \n"
      "               rjmp  ALL_TEST_OK           \n"
);


     // stop here on failure
     // replace by an exit if necessary
__asm("Failure:        jmp   Failure              \n"
      "ALL_TEST_OK:                               \n"
);

  return 1;
}

#ifdef __cplusplus
}
#endif
