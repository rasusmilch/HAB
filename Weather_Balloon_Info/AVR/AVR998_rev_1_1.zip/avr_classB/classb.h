//!
//! @file $RCSfile: classb.h,v $
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief classb header file 
//!
//! @version $Revision: 1.3 $
//!

/****************************************************************************
  One by one startup tests
****************************************************************************/
void Startup_Test(void);

/****************************************************************************
  LastResetReason holds the last reason of reset.
****************************************************************************/
extern unsigned char LastResetReason;
  // Defined reset reasons.
  #define RESET_POWER_ON     0
  #define RESET_RESET_PIN    1
  #define RESET_BROWN_OUT    2
  #define RESET_WATCH_DOG    3
  #define RESET_JTAG         4
  #define RESET_WAITING      0x80
