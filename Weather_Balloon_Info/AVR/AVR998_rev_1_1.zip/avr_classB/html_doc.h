/*!
* \mainpage
* \section section1 Description
*   This application gives an example to start a Class B compliant application\n
*   It runs on an ATmega16 part\n
*   The main sources files are :
*
*         -  main.c           main loop
*         -  classB.c         test fonctions in C
*         -  low_level_init.c tests performed before C context initialization
*                                 it is written in assembler
*
*
*
* \section section2 Preamble
* All parameters are given for the ATmega16 \n
* They must be ajusted according to the microcontroller
* \n
*
* \section section3 User Manual
* This test will execute the application when the test is OK \n
* Please adapt this firmware to your application \n
* Remove the factice application which makes one led blinking. \n
* This firmware has been tested with IAR Workbench. \n
* It can easily modified to be used with GCC or other C compilers
*
* \subsection subsection1 List of Tests
*   - Register test
*   - Watchdog test
*   - Cpu_status test
*   - Sram test
*   - Timer0 test
*   - Timer1 test
*   - Timer2 test
*   - Interrupt test
*
*
*/