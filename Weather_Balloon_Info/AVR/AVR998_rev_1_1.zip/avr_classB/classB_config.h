//!
//! @file $RCSfile: classB_config.h,v $
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief Define the following constants according to your settings.
//!
//! @version $Revision: 1.2 $
//!

#define SRAM_START_ADR    0x0060

// ATmega16
#define SRAM_SIZE         1024
#define SRAM_END_ADR      SRAM_START_ADR + SRAM_SIZE -1
#define SRAM_START_PAGE2  0x0100
/*
// ATmega32
#define SRAM_SIZE         2048
#define SRAM_START_PAGE2  0x0100
*/

#define SPH_MASK          "0x07\n"

#define STACK_SAV         0x0250
#define STACK_ADR         0x0099 
