//!
//! @file $RCSfile: main.c,v $
//!
//! Copyright (c) 2007 Atmel.
//!
//! @brief Main module : It is based on an infinite loop
//!
//! @version $Revision: 1.4 $
//!

//_____  I N C L U D E S ___________________________________________________
#include "ioavr.h"
#include "classb.h"

void application_example (void);

//! @brief main entry point for the firmware
//!/
int main( void )
{

  DDRA=0xFF;
  PORTA=0xFF;
  PINA=0xFF;
  
  Startup_Test(); /* Class B Test */
  
  while (1)
  { /* place here your main application */
    /* the following instructions are example */
    application_example();
  }
}

//! @brief application example
//!   - remove it when there is an application
//!   - toggle PA0 at high speed
//!   - toggle PA2 at low speed
//!   - on STK500: connect PortA to leds
//!/
void application_example (void)
{
  unsigned int i; //!< index
  
  for (i=1;i<60000;i++)
  {
    PORTA&=~(1<<PORTA0);   /* clear PA0 */
    PORTA|=(1<<PORTA0);    /* set PA0 */
  }
  PORTA&=~(1<<PORTA2);     /* clear PA2 */
  for (i=1;i<10000;i++)
  {
    PORTA&=~(1<<PORTA0);   /* clear PA0 */
    PORTA|=(1<<PORTA0);    /* set PA0 */
  }
  PORTA|=(1<<PORTA2);      /* set PA2 */
}


