Adafruit Data Logger Shield PCB
===============================

PCB files for Adafruit's Data Logger Shield for Arduino

For more details, check out the product page at

-----> https://www.adafruit.com/product/1141

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution